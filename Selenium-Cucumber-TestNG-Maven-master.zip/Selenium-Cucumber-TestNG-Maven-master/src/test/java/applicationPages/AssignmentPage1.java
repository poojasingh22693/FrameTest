package applicationPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import methods.SeleniumHelper;

public class AssignmentPage1 {

	WebDriver driver;

	SeleniumHelper sh=new SeleniumHelper(driver);

	public static final By QA_ASSiGNMENT = By.xpath("//a[text()='qa-engineer-assignment/']");
	public static String URL="http://localhost:8000/";

	public AssignmentPage1(WebDriver driver) {
		this.driver=driver;


	}

	public void openPage() {

		driver.get(URL);

	}
	
	public void clickLink() throws Exception{

		sh.jsClick(QA_ASSiGNMENT);

	}

}


