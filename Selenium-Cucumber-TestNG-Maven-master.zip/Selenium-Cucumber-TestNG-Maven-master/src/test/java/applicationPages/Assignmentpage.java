package applicationPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import methods.SeleniumHelper;
import webConnector.Webconnector;

public class Assignmentpage extends Webconnector {
	SeleniumHelper sh=new SeleniumHelper(driver);

	public WebDriver getDriver() {
		return driver;
	}
	//WebDriver driver;

	
//	@FindBy(xpath="//a[text()='qa-engineer-assignment/']")
//	private WebElement qa_Asssignment_Link;
//	
//	public static final By ITEM_NAME = By.cssSelector(".inventory_item_name");
//    public static final By RESET_APP_STATE = By.id("reset_sidebar_link");
//    public static final By CHECKOUT_BUTTON = By.cssSelector(".btn_action.checkout_button");
   public static final By QA_TEST = By.xpath("//a[text()='qa-engineer-assignment/']");
//    public static final By OPEN_MENU = By.xpath("//button[text()='Open Menu']");
//    public static final By CLOSE_MENU = By.xpath("//button[text()='Close Menu']");
//    public static final By ITEM_MENU = By.id("inventory_sidebar_link");
	
	
	  //Constructor
//	   public Assignmentpage(WebDriver driver){
//	       this.driver=driver;
//
//	       //Initialise Elements
//	       PageFactory.initElements(driver, this);
//	   }
	
	//
	//	public Assignmentpage() {
	//		PageFactory.initElements(driver, this);
	//	}


	/* Implementations for Scenario: Check Assignment Page displayed*/
	public void goToAssignmentPage() throws Exception{
		//  String URL=wc.getSpecificColumnData("./src/test/testdata/data.xlsx","sheet1", "URL");
		//String URL="https://www.google.co.in/";
		//wc.driver.get(URL);
		//  driver.get(URL);
		//wc.waitForCondition("PageLoad","",60);
		//qa_Asssignment_Link.click();
		//
		//methods.jsClick(qa_Asssignment_Link, driver);
		System.out.println(driver.getCurrentUrl());
		System.out.println(driver.getWindowHandle());
		Assert.assertTrue(driver.findElement(QA_TEST).isDisplayed());
		sh.jsClick(QA_TEST);
//		JavascriptExecutor js = (JavascriptExecutor) driver;
//		js.executeScript("arguments[0].click();", driver.findElement(QA_TEST));
		//	WebDriver driver = wc.getDriver();
		//	driver.findElement(By.xpath("//a[text()='.p2/']")).click();		
		//SeleniumUtils.jsClick(qa_Asssignment_Link);
		//wc.waitForCondition("PageLoad","check",20);
		//wc.jsScroll(check);
		//wc.clickUsingAction(check);
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("arguments[0].click();", qa_Asssignment_Link);
		//Assert.assertTrue(qa_Asssignment_Link.isDisplayed());
		//wc.PerformActionOnElement(check);
		//wc.PerformActionOnElement(check, "Click", null);
		//wc.FindAnElement("//a[text()='qa-engineer-assignment/']");
		//wc.jsClick(xpath("//a[text()='qa-engineer-assignment/']"));
	//	wc.jsClick("qa-engineer-assignment");
	}

	public void validatesFieldsDisplayed() {}

	/*Implementations for Scenario: Validation of create question button functionality*/
	public void	detailsForCreatingQuestion() {}
	public void validationOfCreateQuestionAddition() {}
	public void validationOfMoreThanOneQuestion() {}

	/* Implementations for Scenario: Validation of Sort questions button functionality*/
	public void clickOnSortQuestionsButton() {}
	public void validationOfSortQuestions() {}

	/* Implementations for Scenario: Validation of Remove questions button functionality*/
	public void clickOnRemoveQuestionsButton(){}
	public void validationOfRemoveQuestions(){}


}